rootProject.name = "REstaurant"


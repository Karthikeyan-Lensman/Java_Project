package com.thoughtworks.codepairing.service;

import com.thoughtworks.codepairing.models.MenuItem;
import com.thoughtworks.codepairing.models.Restaurant;

public class OrderService implements IOrderService {

    public int calculateTotal(String[] itemCodes) {
        int total = 0;

        for (String code : itemCodes) {
            MenuItem item = Restaurant.getItemByCode(code.trim());
            if (item == null) {
                System.out.println("Incorrect Code: " + code + " Item Not available in the restaurant");
                return -1;
            }
            total += item.getPrice();
        }

        if (total < 300) {
            total += 50; // service charge
        }

        return total;
    }
}

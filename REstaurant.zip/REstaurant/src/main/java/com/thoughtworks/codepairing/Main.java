package com.thoughtworks.codepairing;


import com.thoughtworks.codepairing.service.OrderService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter item codes (comma-separated): ");
        String input = scanner.nextLine();

        String[] itemCodes = input.split(",");

        OrderService orderService = new OrderService();
        int total = orderService.calculateTotal(itemCodes);

        if (total != -1) {
            System.out.println("Output: ₹ " + total);
        }
    }
}
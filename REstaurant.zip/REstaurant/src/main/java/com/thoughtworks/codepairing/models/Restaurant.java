package com.thoughtworks.codepairing.models;

import java.util.HashMap;
import java.util.Map;

public class Restaurant {
    private static final Map<String, MenuItem> menu = new HashMap<>();

    static {
        menu.put("A001", new MenuItem("A001", "Fried Rice", 220));
        menu.put("A002", new MenuItem("A002", "Hakka Noodles", 200));
        menu.put("A003", new MenuItem("A003", "Cold Coffee", 100));
        menu.put("A004", new MenuItem("A004", "Fresh Juice", 80));
    }

    public static MenuItem getItemByCode(String code) {
        return menu.get(code);
    }
}
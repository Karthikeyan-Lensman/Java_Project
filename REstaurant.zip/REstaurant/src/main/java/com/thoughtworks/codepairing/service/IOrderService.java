package com.thoughtworks.codepairing.service;

public interface IOrderService {
    int calculateTotal(String[] itemCodes);
}